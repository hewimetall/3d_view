# raygui CMake Definitions

This provides CMake definition files for raygui.

## Usage

```
cd projects/CMake
mkdir build
cd build
cmake ..
make
```