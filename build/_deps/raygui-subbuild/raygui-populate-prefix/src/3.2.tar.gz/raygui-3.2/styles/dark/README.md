style: dark
--------------
Classical dark style with an extra high-def colour touch! Elegant and professional, perfect for the expensive tools!

![dark style table](dark_table.png)

screenshot
-----------

![dark style screen](screenshot.png)

about font
-----------
"Pixel Operator" font by de Jayvee Enaguas.

CC0 1.0 Universal, downloaded from dafont.com: [pixel-operator](https://www.dafont.com/pixel-operator.font)
