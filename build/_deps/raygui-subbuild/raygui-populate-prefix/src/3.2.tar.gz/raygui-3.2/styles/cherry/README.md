style: cherry
--------------
Sweet with a touch of liquour, covered in chocolate, just give it a try! Not suitable for every palate, only the most demanding. 

![cherry style table](style_table.png)

screenshot
-----------

![cherry style screen](screenshot.png)

about font
-----------
"Westington" font by Hazel Abbiati.

100% free font, downloaded from dafont.com: [westington](https://www.dafont.com/westington.font)
