style: default
---------------
raylib style, simple and easy-to-use. Light colors, wide borders, a sophisticated touch.

![default style table](style_table.png)

screenshot
-----------

![default style screen](screenshot.png)

about font
-----------
raylib font by Ramon Santamaria ([@raysan5](https://twitter.com/raysan5)).
