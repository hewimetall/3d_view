style: ashes
-------------
What once was life now is ashes, just as slight reminiscense covers the ground, a gray sequence of tones that reminds to a distant past.

![ashes style table](style_table.png)

screenshot
-----------

![ashes style screen](screenshot.png)

about font
-----------
"V5 Loxica Lixera" font by vFive Digital (Roberto Christen).

100% free font, downloaded from dafont.com: [v5loxica-lixera](https://www.dafont.com/v5loxica-lixera.font)
