style: enefete
--------------
Inspired by money and pain, a desperate jump into the trendings train, a train to nowhere. Don't stare at it for too long!

![enefete style table](enefete_table.png)

screenshot
-----------

![enefete style screen](screenshot.png)

about font
-----------
"Generic Mobile System" font by de Jayvee Enaguas.

CC0 1.0 Universal, downloaded from dafont.com: [generic-mobile-system](https://www.dafont.com/generic-mobile-system.font)
